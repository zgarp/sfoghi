/* ============================================================
   entries.js — your content index lives here
   ============================================================
   To add a new entry:
   1. Write your text in a new .txt file inside the texts/ folder
      (name it anything you like, e.g. texts/2026-04-01.txt)
   2. Add a new block at the TOP of the array below with:
        date  — shown in small text above the title
        title — the heading of the entry
        file  — the path to your .txt file
   3. Save this file. That's it.
   ============================================================ */

const entries = [
  {
    date:  "21 March 2026",
    title: "Second entry",
    file:  "text_files/21-03-2026_bis.txt"
  },
  {
    date:  "21 March 2026",
    title: "First entry",
    file:  "text_files/21-03-2026.txt"
  },
];
